public class DBAppException extends Exception{
}
