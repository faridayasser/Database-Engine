import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;

public class column implements java.io.Serializable {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	static String csvUrl = "src/main/resources/metadata.csv";

	public static String getCsvUrl() {
		return csvUrl;
	}

	public static void setCsvUrl(String csvUrl) {
		column.csvUrl = csvUrl;
	}

	public double getMin() {
		return min;
	}

	public void setMin(double min) {
		this.min = min;
	}

	public double getMax() {
		return max;
	}

	public void setMax(double max) {
		this.max = max;
	}

	public Double[] getRanges() {
		return ranges;
	}

	public void setRanges(Double[] ranges) {
		this.ranges = ranges;
	}

	public int getJumps() {
		return jumps;
	}

	public void setJumps(int jumps) {
		this.jumps = jumps;
	}

	static String table;
 String name;
	Double min;
	Double max;
	Double[] ranges = new Double[10];
	int jumps;

	public column(String tablename, String n) {
		name = n;
		table = tablename;
		Object mino = minimum();
		Object maxo = maximum();
		if (mino instanceof String) {
			min = (double) ascii((String) mino);
			max = (double) ascii((String) maxo);
		} else if(mino instanceof Integer){
			min = (double) (int)mino;
			max = (double) (int)maxo;
		}
		else
		{
			min =(double) mino;
			max =(double)maxo;
		}

		jumps = getnumofValues();
		showMins();
		

	}

	@SuppressWarnings("deprecation")
	/*public int compareT(Date f, Date d) {
		int diffYear=-1;
		if (d.getYear() == f.getYear()) {
			if (d.getMonth() > f.getMonth()) {
				int diffmonth = d.getMonth() - f.getMonth();
				// range will be with month
			} else if (f.getMonth() > d.getMonth()) {
				int diffmonth = f.getMonth() - d.getMonth();
			} else { // month and year are equal check days
				if (d.getDay() > f.getDay()) {
					int diffDays = d.getDay() - f.getDay();
					// range will be with days
				} else if (f.getDay() > d.getDay()) {
					int diffDays = f.getDay() - d.getDay();
				}

			}
		} else if (d.getYear() - f.getYear() < 8 || f.getYear() - d.getYear() < 8) { // check month alatool
			if (d.getYear() - f.getYear() <= 1 || f.getYear() - d.getYear() <= 1) {
				// divide according to month (12 month difference)
			} else { // more than 1 year difference
				if (d.getMonth() > f.getMonth()) {
					int diffmonth = d.getMonth() - f.getMonth();
					// range will be with month
				} else if (f.getMonth() > d.getMonth()) {
					int diffmonth = f.getMonth() - d.getMonth();
				} else { // month and year are equal check days
					if (d.getDay() > f.getDay()) {
						int diffDays = d.getDay() - f.getDay();
						// range will be with days
					} else if (f.getDay() > d.getDay()) {
						int diffDays = f.getDay() - d.getDay();
					}

				}
			}
		} else {// hena diff years > 8 fa divide ranges according to year
			if (d.getYear() > f.getYear()) {
				 diffYear = d.getYear() - f.getYear();
				// range will be with month
			} else if (f.getYear() > d.getYear()) {
				 diffYear = f.getYear() - d.getYear();
			}

			if (diffYear >= 8 & diffYear <= 10) {
				// divide ala diff years alatool 8 or 9 or 10 ranges
			} else {
				// hena divide on 10 ranges
			}
		}

	}*/

	public static Double ascii(String name) {
		
		// String to check it's value
		int nameLenght = name.length(); // length of the string used for the loop
		Double ascii = (double) 0;
		for (int i = 0; i < nameLenght; i++) { // while counting characters if less than the length add one
			char character = name.charAt(i); // start on the first character
			ascii = ascii + (int) character; // convert the first character
			// print the character and it's value in ascii
		}
		return ascii;
	}
	
	public Object minimum() {
		Hashtable<String, String> h = getType();

		return convertSt(h.get("Min"), h.get("Type"));

	}

	public Object maximum() {
		Hashtable<String, String> h = getType();

		return convertSt(h.get("Max"), h.get("Type"));
	}

	public double compare(Object min, Object value) {
		if (!min.getClass().equals(value)) {
			// throw new DBAppException();
		}
		if (min instanceof String) {

			return ((String) value).compareTo((String) min);

		} else if (min instanceof Date) {
			return ((Date) value).compareTo((Date) min);

		} else if (min instanceof Double) {
			return ((Double) value - (Double) min);
		} else {
			return (int) value - (int) min;
		}
	}

	/*
	 * public int compareT(Date s, Date d) { if (d.getYear()-s.getYear()<10) {
	 * if(d.getMonth()!=s.getMonth()&& d.getYear()==s.getYear()) }
	 * if(d.getYear()>s.getYear()) { return d.getYear()-s.getYear(); }
	 * 
	 * }
	 */
	public void showMins() {
		int i = 0;
		double m = min;
		// ranges[0]=m;
		int x = getnumofValues();
		while (m <= max) {
			ranges[i] = m;
			m = m + x;

			i++;
		}

	}

	public int getnumofValues() {
		int x = (int) (((max - min) + 1) / 10);
		Double y = ((max - min) + 1);
		if (y % 10 != 0) {
			x = x + 1;
		}
		//jump=x;
		return x;
	}

	/*
	 * public String getLoc(Object o) { //hashof el object da f anhy range int index
	 * = compare(min,o)/jumps; return ""+index; }
	 */
	public Object convertSt(String st, String type) {
		type = type.toLowerCase();
		if (type.contains("Integer".toLowerCase()))// changed from equals java.util.lang to contains each
			return Integer.parseInt(st);
		else if (type.contains("Double".toLowerCase()))
			return Double.parseDouble(st);
		else if (type.contains("Date".toLowerCase())) {
			return Date.valueOf(st);
		}
		return st;
	}

	public ArrayList readFile() {
		String currentLine = "";
		ArrayList line = new ArrayList();
		FileReader fileReader;
		try {
			fileReader = new FileReader(csvUrl);
			BufferedReader br = new BufferedReader(fileReader);
			while ((currentLine = br.readLine()) != null) {
				String[] line1 = currentLine.split(",");
				line.add(line1);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return line;
	}

	public Hashtable<String, String> getType() {
		Hashtable<String, String> h = new Hashtable<String, String>();
		ArrayList a = readFile();
		for (int i = 0; i < a.size(); i++) {
			String[] b = (String[]) a.get(i); // a =l
			if (b[0].compareTo(table) == 0 && b[1].equalsIgnoreCase(name)) {
				h.put("Type", b[2]);
				h.put("Min", b[5]);
				h.put("Max", b[6]);
			}

		}
		return h;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		column.table = table;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public static void main(String[]args) {
		Double []ra = new Double[10];
		
		String a = "zzzzzz";
		String b = "AAAAAA";
		String z = "yEpejp";
		Double min = ascii(b);
		Double max = ascii(a);
		Double r  = ascii(z);
		int x = (int) (((max - min) + 1) / 10);
		Double y = ((max - min) + 1);
		if (y % 10 != 0) {
			x = x + 1;
		}
		int i = 0;
		double m = min;
		// ranges[0]=m;
		//int x = getnumofValues();
		while (m <= max) {
			ra[i] = m;
			m = m + x;

			i++;
		
	}
		
		System.out.println(x);//-33
		System.out.println(Arrays.toString(ra));
		
	}
}